export enum PublicRoutes {
  LOGIN = '/login',
  LOGOUT = '/logout'
}

export enum ProtectedRoutes {
  DASHBOARD = '/dashboard'
}
