export default interface AuthContract {
    email : string;
    token : string;
}