export default interface LoginContract {
    email: string;
    password : string;
}