interface ProductCategoryContract {
    productCategoryId: number;
    name: string;
    description: string;
}

export default ProductCategoryContract